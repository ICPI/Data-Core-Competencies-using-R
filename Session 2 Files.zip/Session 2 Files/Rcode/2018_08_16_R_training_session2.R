

#___________________________________________________________________________
#
#         ___  2
#         |__) 
#         |  \    R Training Session II   
#
#___________________________________________________________________________




## Installing and loading Tidyverse package
#  install.packages("tidyverse")
library(tidyverse)


#--------------------------------------------------------------
# ---- (0) Importing the dataset ----- 
#--------------------------------------------------------------
# Pulling in the dataset for next steps
 # Pulling in training data from GitHub
df <- read_tsv("./RawData/ex2_data.txt",
                      col_types = cols(MechanismID      = "c",
                                     AgeAsEntered       = "c",            
                                     AgeFine            = "c",     
                                     AgeSemiFine        = "c",    
                                     AgeCoarse          = "c",      
                                     Sex                = "c",     
                                     resultStatus       = "c",     
                                     otherDisaggregate  = "c",     
                                     coarseDisaggregate = "c",     
                                     FY2017_TARGETS     = "d",
                                     FY2017Q1           = "d",      
                                     FY2017Q2           = "d",      
                                     FY2017Q3           = "d",      
                                     FY2017Q4           = "d",      
                                     FY2017APR          = "d",
                                     FY2018Q1           = "d",
                                     FY2018Q2           = "d",
                                     FY2018_TARGETS     = "d"))
spec(df)
View(df[1:20, ])


#--------------------------------------------------------------



#--------------------------------------------------------------
# ---- (1) Creating New Variables (Mutate) (Slide )----- 
#--------------------------------------------------------------
View(count(df, PrimePartner))

# Dividing FY2017APR values by 10
df2 <- mutate(df, FY2017APR_true = FY2017APR/10)

# Above step AND doubling the FY18 Q2 values
df2 <- mutate(df, FY2017APR_true = FY2017APR/10, FY2018Q2_true = FY2018Q2 *2) 

View (select(df2, FY2017APR, FY2017APR_true))

# New Partner Names, one change
# mutate() and ifelse() make for a powerful combination in tandem.
# if_else fucntion comprable to IF function in excel 
df3 <- mutate(df, 
              newpartnername = if_else(
                PrimePartner == "Stark", "SansaStark", PrimePartner))
View(count(df3, PrimePartner, newpartnername))


# New Partner Names, multiple changes. 
df4 <- mutate(df, newpartnername = 
                if_else(PrimePartner == "Stark", "Ned's Family", 
                        if_else(PrimePartner == "First Men", "First Men & Women", 
                                if_else(PrimePartner == "Ice" , "Ice & Fire", PrimePartner))))
View(count(df4, PrimePartner, newpartnername))



#Creating Cumulative Column   FIX THIS 

                                  
                                  
df5 <- mutate(df, FY18CUM = FY2018Q1 + FY2018Q2)

View (arrange(df5, desc(FY18CUM)))




# Recoding Existing variables: 

df6 <- mutate(df4, newpartnername = 
                if_else(newpartnername == "Ned's Family", "ScatteredStarks", newpartnername))

View(count(df5, newpartnername))


#--------------------------------------------------------------


#-------------------------------------------------------
# ---- (2) Cleaning your data (Slide )----- 
#--------------------------------------------------------
# Removing values with 'NA' 
# reading in the dataset with NA values in Sex
na_df <- read_tsv(file="./RawData/na_data.txt", 
                  col_types = cols(MechanismID        = "c",
                                   AgeAsEntered       = "c",            
                                   AgeFine            = "c",     
                                   AgeSemiFine        = "c",    
                                   AgeCoarse          = "c",      
                                   Sex                = "c",     
                                   resultStatus       = "c",     
                                   otherDisaggregate  = "c",     
                                   coarseDisaggregate = "c",     
                                   FY2017_TARGETS     = "d",
                                   FY2017Q1           = "d",      
                                   FY2017Q2           = "d",      
                                   FY2017Q3           = "d",      
                                   FY2017Q4           = "d",      
                                   FY2017APR          = "d",
                                   FY2018Q1           = "d",
                                   FY2018Q2           = "d",
                                   FY2018_TARGETS     = "d"))


# Checking the data 
count(na_df, Sex)


# Removing N/A or other undesireable values and convert to 
# True missing, or blank ""

na_df1 <- mutate(na_df, Sex = if_else(Sex == "N/A", "", Sex))  #converts to blanks
count(na_df1, Sex)

# when running models, true <NA> is treated as "missing"
# while blank "" is treated as another category for the variable
# Numeric variables will not accept "", but will have true <NA> only
#-------------------------------------------------------




#--------------------------------------------------------------
# ---- (3) Renaming Variables (Rename) (Slide )----- 
#--------------------------------------------------------------

View(df[1:20,])

df7 <- rename(df, Partner = PrimePartner, Agency = FundingAgency)

View(df7)



#--------------------------------------------------------------



#--------------------------------------------------------------
# ---- (4) Deleting Variables (Slide )----- 
#--------------------------------------------------------------

View(df6[1:20,])

# Let's remove UIDs
df8 <- select(df7 ,-RegionUID, -OperatingUnitUID, -SNU1UID, -PSNUuid, -MechanismUID)

View(df7[1:20,])

#--------------------------------------------------------------





#----------------------------------------------------------------------
# ---- (5) Piping %>%  - Bringing It All Together  (Slide )----- 
#----------------------------------------------------------------------


# Pipes let you take the output of one function and send it directly to the next, 
# which is useful when you need to do many things to the same dataset

# %>% returns an object, you can actually allow the calls to be 
# chained together in a single statement, without needing variables 
# to store the intermediate results.



# Examples:
# Positives found by Total Numerator:
hts1 <- df %>%   # this is the pipe! goes at end of every function statement 
  filter(indicator == "HTS_TST_POS" & standardizedDisaggregate == "Total Numerator") %>%
    select (OperatingUnit, indicator, PSNU, PrimePartner, FundingAgency, FY2018Q1, FY2017APR)

View(hts1[1:20,])


# Same example Without Piping:
hts_nopipe <- filter (df, indicator == "HTS_TST_POS" & standardizedDisaggregate == "Total Numerator")
hts_nopipe2 <- select(hts_nopipe, OperatingUnit, indicator, PSNU, PrimePartner, FundingAgency, FY2018Q1, FY2017APR)

View(hts_nopipe2[1:20,])



# New on treatment by OU and disagg type
tx2 <- df %>%
  filter(indicator == "TX_NEW" & FY2017APR >0 ) %>%
    rename (disagg_type = standardizedDisaggregate ) %>% 
      select (OperatingUnit, indicator, PSNU, disagg_type, FY2017APR)

View(count(tx2, disagg_type, FY2017APR))



tx3 <- df %>% 
  filter((indicator == "TX_CURR" | indicator == "TX_NEW") & standardizedDisaggregate == "Total Numerator") %>%
    mutate (newpartnername = if_else(PrimePartner == "Stark", "Ned's Family", PrimePartner)) %>% 
      select (OperatingUnit, SNU1, SNUPrioritization, PSNU, newpartnername, indicator, standardizedDisaggregate, FY2017APR) %>%
       arrange (newpartnername) %>%
        rename (disagg_type = standardizedDisaggregate) 

View(tx3)
View(count(tx3, indicator, disagg_type))



#--------------------------------------------------------------




#----------------------------------------------------------------------
# ---- (5) Stacking Datasets  (Slide )----- 
#----------------------------------------------------------------------


         
# Use rbind function to stack or merge datasets by rows 

df_double <- rbind(df, na_df)


# If one dataset has variables that the other dataset does not, then either:
  
# Delete the extra variables or
# Create the additional variables in the dataset without and set them to blank
# before joining them with rbind( ).


# Example

names(df5) # to see column names

df10 <-  mutate(df5, FY18CUM = "" )  # setting new var to blank

View(select(df10, FY18CUM))   # verifying
    
df_double2 <- rbind(df5, df10)
View(select(df_double2,FY18CUM))







